package bean;

public class RegisterBean 

	{
		private String FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password;
		int srNo;
		public String getFirstName() {
			return FirstName;
		}
		public void setFirstName(String firstname) {
			FirstName = firstname;
		}
		public String getLastName() {
			return LastName;
		}
		public void setLastName(String lastname) {
			LastName = lastname;
		}
		public String getEmail() {
			return Email;
		}
		public void setEmail(String email) {
			Email = email;
		}
		public String getPhoneNumber() {
			return PhoneNumber;
		}
		public void setPhoneNumber(String phonenumber) {
			PhoneNumber = phonenumber;
		}
		public String getCompanyName() {
			return CompanyName;
		}
		public void setCompanyName(String companyname) {
			CompanyName = companyname;
		}
		public String getCity() {
			return City;
		}
		public void setCity(String city) {
			City = city;
		}
		public String getCountry() {
			return Country;
		}
		public void setCountry(String country) {
			Country = country;
		}
		public String getPassword() {
			return Password;
		}
		public void setPassword(String password) {
			Password = password;
		}

	}

