package action;

import java.sql.ResultSet;
//import java.util.ArrayList;
import java.util.List;

import com.opensymphony.xwork2.ActionSupport;

import bean.RegisterBean;
import dao.RegisterDao;


public class ReportAction extends ActionSupport{

	
	private static final long serialVersionUID = 1L;
	
	ResultSet rs = null;
	RegisterBean bean = null;
	List<RegisterBean> beanList = null;
	RegisterDao admin = new RegisterDao();
	private boolean noData = false;
	private String Email,FirstName,LastName,PhoneNumber,CompanyName,City,Country,Password;
	String submitType;
	@Override
	public String execute() throws Exception {
		try {
			if (submitType.equals("reportdata")) 
			{
				int i=0;
				rs = admin.fetchUserDetails(Email.trim());
				if (rs != null) 
				{
					bean = new RegisterBean();
					
					bean.setFirstName(rs.getString("FirstName"));
					bean.setLastName(rs.getString("LastName"));
					bean.setEmail(rs.getString("Email"));
					bean.setPhoneNumber(rs.getString("PhoneNumber"));
					bean.setCompanyName(rs.getString("CompanyName"));
					bean.setCity(rs.getString("City"));
					bean.setCountry(rs.getString("Country"));
					//bean.setPassword(rs.getString("Password").replaceAll("(?s).", "*"));
					
					beanList.add(bean);
					i++;
				}
			if (i == 0) 
			{
				noData = false;
			} 
			else 
			{
				noData = true;
			}
			}
			}catch (Exception e) {
			e.printStackTrace();
		}
		return "REPORT";
	}

	public boolean isNoData() {
		return noData;
	}

	public void setNoData(boolean noData) {
		this.noData = noData;
	}

	public List<RegisterBean> getBeanList() {
		return beanList;
	}

	public void setBeanList(List<RegisterBean> beanList) {
		this.beanList = beanList;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}
}


