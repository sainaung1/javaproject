package action;

import java.io.IOException;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	public String execute() throws IOException{
		return "login1";
}
}
