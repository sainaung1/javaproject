package action;

import java.sql.ResultSet;

import com.opensymphony.xwork2.ActionSupport;

import dao.RegisterDao;


public class UpdateAction extends ActionSupport{


	private static final long serialVersionUID = 1L;
	private String FirstName = "", LastName = "", Email = "", PhoneNumber = "", CompanyName = "", City = "",Country = "", Password = "";
	private String msg = "";
	ResultSet rs = null;
	RegisterDao dao = new RegisterDao();
	String submitType;

	@Override
	public String execute() throws Exception {
		try {
			if (submitType.equals("updatedata")) {
				rs = dao.fetchUserDetails(Email.trim());
				if (rs != null) {
					while (rs.next()) {
						FirstName = rs.getString("FirstName");
						LastName = rs.getString("LastName");
						Email = rs.getString("Email");
						PhoneNumber = rs.getString("PhoneNumber");
						CompanyName = rs.getString("CompanyName");
						City = rs.getString("City");
						Country = rs.getString("Country");
						Password = rs.getString("Password");

					}
				}
			} else {
				int i = dao.updateUserDetails(FirstName,LastName,Email,PhoneNumber,CompanyName,City,Country,Password);
				if (i > 0) {
					msg = "Record Updated Successfuly";
				} else {
					msg = "error";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "UPDATE";
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstname) {
		this.FirstName = firstname;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastname) {
		this.LastName = lastname;
	}
	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email = email;
	}
	
	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phonenumber) {
		this.PhoneNumber = phonenumber;
	}
	
	
	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyname) {
		this.CompanyName = companyname;
	}
	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		this.City = city;
	}
	
	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		this.Country = country;
	}
	
	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public String getSubmitType() {
		return submitType;
	}

	public void setSubmitType(String submitType) {
		this.submitType = submitType;
	}

}
